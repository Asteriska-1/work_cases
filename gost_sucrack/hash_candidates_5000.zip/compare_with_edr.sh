#!/usr/bin/env bash
set -euo pipefail

FEED_PATH="${1:-/opt/vxagent/bin/modules/vxlua-90237938/data/feed.json}"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
CANDIDATES_TSV="${SCRIPT_DIR}/hash_candidates_5000.tsv"
OUT_TSV="${PWD}/edr_candidate_matches.tsv"
OUT_HASHES="${PWD}/edr_candidate_match_hashes.txt"

if [[ ! -r "$FEED_PATH" ]]; then
    echo "ERROR: feed is not readable: $FEED_PATH" >&2
    exit 1
fi

if [[ ! -r "$CANDIDATES_TSV" ]]; then
    echo "ERROR: candidate list is not readable: $CANDIDATES_TSV" >&2
    exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

# feed.json is NDJSON: each line is {"sha256":"verdict"}.
jq -r 'to_entries[] | [.key, .value] | @tsv' "$FEED_PATH" \
    | LC_ALL=C sort -t $'\t' -k1,1 \
    > "$TMP_DIR/edr.tsv"

tail -n +2 "$CANDIDATES_TSV" \
    | LC_ALL=C sort -t $'\t' -k1,1 \
    > "$TMP_DIR/candidates.tsv"

join -t $'\t' -1 1 -2 1 \
    "$TMP_DIR/edr.tsv" \
    "$TMP_DIR/candidates.tsv" \
    > "$OUT_TSV"

cut -f1 "$OUT_TSV" > "$OUT_HASHES"

MATCH_COUNT="$(wc -l < "$OUT_TSV")"
echo "Matches found: $MATCH_COUNT"
echo "Detailed results: $OUT_TSV"
echo "Hashes only:      $OUT_HASHES"
